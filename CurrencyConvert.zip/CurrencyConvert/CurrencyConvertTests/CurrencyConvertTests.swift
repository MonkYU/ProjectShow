//
//  CurrencyConvertTests.swift
//  CurrencyConvertTests
//
//  Created by allen on 2023/4/30.
//

import XCTest
@testable import CurrencyConvert

final class CurrencyConvertTests: XCTestCase {
    let transViewModel = CurrencyTransViewModel()
    var requestFinish = false
    
    override func setUpWithError() throws {
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testExample() throws {
        for i in 1 ..< 100 {
            // set input amount
            print(transViewModel.rx_currencies.value)
            transViewModel.rx_doubleMountVar.accept(Double(i))
            transViewModel.rx_currencies.value.forEach { [weak transViewModel] currency in
                guard let transViewModel = transViewModel else { return }
                let conversionRet = transViewModel.getAmountForCurrency(currency: currency)
                let output = String(format: "inputNumber:%d, currentCurrency:%@, targetCurrency:%@ conversionRet:%@", i, transViewModel.rx_currentCurrencyVar.value, currency, conversionRet)
                print(output)
            }
        }
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
        // Any test you write for XCTest can be annotated as throws and async.
        // Mark your test throws to produce an unexpected failure when your test encounters an uncaught error.
        // Mark your test async to allow awaiting for asynchronous code to complete. Check the results with assertions afterwards.
    }

    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        self.measure {
            for i in 0 ..< 100 {
                transViewModel.rx_doubleMountVar.accept(Double(i))
            }
            // Put the code you want to measure the time of here.
        }
    }

}
