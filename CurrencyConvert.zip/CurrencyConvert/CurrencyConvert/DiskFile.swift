//
//  DiskFile.swift
//  CurrencyConvert
//
//  Created by allen on 2023/4/30.
//

import Foundation

private let currenciesFilePath = "currencies.data"
private let latestMapFilePath = "latestMap.data"


extension FileManager {
    func currenciesFile() -> String {
        guard let documentPath = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).last else { return "" }
        let currenciesFilePath = documentPath + "/" + currenciesFilePath
        if !self.fileExists(atPath: currenciesFilePath) {
            self.createFile(atPath: currenciesFilePath, contents: nil)
        }
        return currenciesFilePath
    }
    
    func lastestMapFile() -> String{
        guard let documentPath = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).last else { return "" }
        let latestMapFilePath = documentPath + "/" + latestMapFilePath
        if !self.fileExists(atPath: latestMapFilePath) {
            self.createFile(atPath: latestMapFilePath, contents: nil)
        }
        return latestMapFilePath
    }
}
