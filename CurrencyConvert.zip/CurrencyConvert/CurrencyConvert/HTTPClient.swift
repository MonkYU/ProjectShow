//
//  HTTPClient.swift
//  CurrencyConvert
//
//  Created by allen on 2023/4/30.
//

import Foundation
import SwiftyJSON
import Alamofire

class HTTPClient {
    
    static let defaultClient = HTTPClient()
    
    func requestCurrencies(currencies: @escaping ([String]) -> ()?) {
        AF.request("https://openexchangerates.org/api/currencies.json?show_alternative=1", headers: .init(["Cache-Control": "max-age=1800"])).response { response in
            if let resultData = response.data {
                do {
                    let jsonData = try JSON(data: resultData)
                    var currenciesList: [String] = [String]()
                    jsonData.dictionary?.keys.forEach({ ret in
                        currenciesList.append(String(ret))
                    })
                    currencies(currenciesList)
                } catch {
                    currencies([""])
                }
            }
        }
    }
    
    func requestLatest(latest: @escaping ([String: Double]) -> ()?) {
        AF.request("https://openexchangerates.org/api/latest.json?show_alternative=1", parameters: ["app_id": "03346086c2024106a89bcff32f314f08"], headers: .init(["Cache-Control": "max-age=1800"])).response { response in
            if let resultData = response.data {
                do {
                    let jsonData = try JSON(data: resultData)
                    print(jsonData)
                    guard let dict = jsonData.dictionary else { return }
                    guard let rates = dict["rates"]?.dictionary else { return }
                    var map: [String : Double] = [String : Double]()
                    for (key, value) in rates {
                        map.updateValue(value.doubleValue, forKey: key.lowercased())
                    }
                    latest(map)
                } catch {
                    latest(["": 0.0])
                }
            }
        }
    }
}

        
        
        
        
