//
//  CurrencyCategoryTableCell.swift
//  CurrencyConvert
//
//  Created by allen on 2023/4/30.
//

import UIKit
import Foundation

class CurrencyCategoryTableCell: UITableViewCell {
    static let CurrencyCategoryTableCellReuseIdentifier = "CurrencyCategoryTableCellReuseIdentifier"
    static let height = 44.0
    
    private lazy var currencyTitleLabel: UILabel = {
        let label = UILabel()
        label.text = "USD"
        label.textColor = .black
        label.font = .systemFont(ofSize: 10)
        return label
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupUI()
        layoutViews()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

// MARK: private method
extension CurrencyCategoryTableCell {
    private func setupUI() {
        selectionStyle = .none
        contentView.addSubview(currencyTitleLabel)
    }
    
    private func layoutViews() {
        currencyTitleLabel.snp.makeConstraints { make in
            make.center.equalToSuperview()
        }
    }
}

// MARK: public method
extension CurrencyCategoryTableCell {
    func updateCell(title: String) {
        currencyTitleLabel.text = title
    }
}
