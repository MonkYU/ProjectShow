//
//  DeviceManager.swift
//  CurrencyConvert
//
//  Created by allen on 2023/4/30.
//

import Foundation
import UIKit

/// Device Manager
class DeviceManager {
    static let defaultManager = DeviceManager()
    
    let topSafeArea: CGFloat
    let bottomSafeArea: CGFloat

    init() {
        let scene = UIApplication.shared.connectedScenes.first as? UIWindowScene
        let inset = scene?.windows.first?.safeAreaInsets
        topSafeArea = inset?.top ?? 0
        bottomSafeArea = inset?.bottom ?? 0
    }
}
