//
//  CurrencyTransViewModel.swift
//  CurrencyConvert
//
//  Created by allen on 2023/4/30.
//

import Foundation
import RxSwift
import RxCocoa

class CurrencyTransViewModel {
    
    // base currency unit
    static private let baseCurrency = "usd"
    
    // Rx textinput amount
    var rx_doubleMountVar: BehaviorRelay<Double> = BehaviorRelay(value: 0.0)
    
    // Rx current currency string
    var rx_currentCurrencyVar: BehaviorRelay<String> = BehaviorRelay(value: baseCurrency)
    
    // Rx currencies
    var rx_currencies: BehaviorRelay<[String]> = BehaviorRelay(value: [""])

    // Rx latest map
    var rx_latestmap: BehaviorRelay<[String : Double]?> = BehaviorRelay(value: [baseCurrency: 1.0])
    
    init() {
        buildCurrenciesAndLatestFromLocalFile()
        requestCurrenciesAndLatest()
    }
}

// MARK: private method
extension CurrencyTransViewModel {
    /// build currencies and latestMap from local file
    private func buildCurrenciesAndLatestFromLocalFile() {
        do {
            let currenciesData = try Data(contentsOf: URL(fileURLWithPath: FileManager.default.currenciesFile()))
            let currencies: [String]? = try NSKeyedUnarchiver.unarchivedObject(ofClass: NSArray.self, from: currenciesData) as? [String]
            if let currencies = currencies {
                rx_currencies.accept(currencies)
            }
            
            
            let latestMapData = try Data(contentsOf: URL(fileURLWithPath: FileManager.default.lastestMapFile()))
            let latestMap: [String : Double]? = try NSKeyedUnarchiver.unarchivedObject(ofClass: NSDictionary.self, from: latestMapData) as? [String : Double]
            if let latestMap = latestMap {
                rx_latestmap.accept(latestMap)
            }
        } catch {}
    }

    private func requestCurrenciesAndLatest() {
        HTTPClient.defaultClient.requestCurrencies { [weak self] currencies in
            guard let self = self else { return }
            self.rx_currencies.accept(currencies)
            do {
                let data = try NSKeyedArchiver.archivedData(withRootObject: currencies, requiringSecureCoding: false)
                try data.write(to: URL(fileURLWithPath: FileManager.default.currenciesFile()))
            } catch {
                
            }
        }
        HTTPClient.defaultClient.requestLatest { [weak self] rates in
            guard let self = self else { return }
            self.rx_latestmap.accept(rates)
            do {
                let data = try NSKeyedArchiver.archivedData(withRootObject: rates, requiringSecureCoding: false)
                try data.write(to: URL(fileURLWithPath: FileManager.default.lastestMapFile()))
            } catch {
                
            }
        }
    }
}

// MARK: public method
extension CurrencyTransViewModel {
    
    /// calculate conversion result
    func getAmountForCurrency(currency: String) -> String {
        if rx_currentCurrencyVar.value.lowercased() == CurrencyTransViewModel.baseCurrency.lowercased() {
            guard let ratio: Double = rx_latestmap.value?[String(currency.lowercased())] else { return "N/A" }
            let finalValue = rx_doubleMountVar.value * ratio
            return String(format: "%.3f", finalValue)
        } else {
            guard let ratio: Double = rx_latestmap.value?[String(currency.lowercased())] else { return "N/A" }
            if ratio == 0.0 { return "0.0" }
            guard let currentCurrencyRatio = rx_latestmap.value?[String(rx_currentCurrencyVar.value.lowercased())] else { return "N/A" }
            if currency.lowercased() == CurrencyTransViewModel.baseCurrency.lowercased() {
                let finalValue = rx_doubleMountVar.value * 1.0 / ratio
                return String(format: "%.3f", finalValue)
            } else {
                let finalValue = rx_doubleMountVar.value * ratio / currentCurrencyRatio
                return String(format: "%.3f", finalValue)
            }
        }
    }
}
