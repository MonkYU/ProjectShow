//
//  ViewController.swift
//  CurrencyConvert
//
//  Created by allen on 2023/4/30.
//

import UIKit
import SwiftyJSON
import Alamofire
import RxSwift

class ViewController: UIViewController {
    
    private let disposeBag = DisposeBag()
    
    private lazy var transViewModel: CurrencyTransViewModel = CurrencyTransViewModel()
    
    private lazy var amountInput: UITextField = {
        let input = UITextField()
        input.keyboardType = .decimalPad
        input.placeholder = "enter currency amount"
        input.layer.borderColor = UIColor.lightGray.cgColor
        input.layer.borderWidth = 1
        return input
    }()
    
    private lazy var categoryView: CurrenciesCategoryView = {
        let view = CurrenciesCategoryView(frame: .zero, viewModel: transViewModel)
        view.layer.borderColor = UIColor.red.cgColor
        view.layer.borderWidth = 1
        return view
    }()
    
    private lazy var collectionView: CurrenciesConversionView = {
        let view = CurrenciesConversionView(frame: .zero, viewModel: transViewModel)
        return view
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        setupObserver()
        layoutViews()
    }

    func setupUI() {
        view.addSubview(collectionView)
        view.addSubview(amountInput)
        view.addSubview(categoryView)
    }
    
    func setupObserver() {
        let _ = amountInput.rx.text.orEmpty.subscribe { [weak self] value in
            guard let element = value.element, let self = self else { return }
            let doubleElement = Double(element) ?? 0.0
            self.transViewModel.rx_doubleMountVar.accept(doubleElement)
        }.disposed(by: disposeBag)
        amountInput.rx.text.orEmpty.scan("") { (previous, new) ->  String in
            if new.last == ".", let contain = previous?.contains("."), contain == true {
                return previous ?? ""
            } else {
                return new
            }
        }
        .subscribe(amountInput.rx.text)
        .disposed(by: disposeBag)
    }
    
    func layoutViews() {
        collectionView.snp.makeConstraints { make in
            make.left.right.equalToSuperview()
            make.bottom.equalTo(view.snp.bottom).offset(-DeviceManager.defaultManager.bottomSafeArea)
            make.top.equalTo(categoryView.snp.bottom).offset(80)
        }
        amountInput.snp.makeConstraints { make in
            make.top.equalTo(view.snp.top).offset(DeviceManager.defaultManager.topSafeArea + 10)
            make.left.equalTo(view.snp.left).offset(40)
            make.right.equalTo(view.snp.right).offset(-40)
            make.height.equalTo(44)
        }
        categoryView.snp.makeConstraints { make in
            make.top.equalTo(amountInput.snp.bottom).offset(30)
            make.right.equalTo(amountInput.snp.right)
            make.width.equalTo(CurrenciesCategoryView.categoryViewWidth)
            make.height.equalTo(CurrenciesCategoryView.tableViewHeight)
        }
    }
}

// MARK: action
extension ViewController {
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        amountInput.resignFirstResponder()
    }
}
