//
//  CurrenciesCategoryView.swift
//  CurrencyConvert
//
//  Created by allen on 2023/4/30.
//

import UIKit
import RxSwift
import Foundation

/// view, display avaliable currencies 
class CurrenciesCategoryView: UIView {
    static let arrowBtnWidth = 40
    static let arrowBtnHeight = 44
    static let tableViewWidth = 80
    static let tableViewHeight = 44
    static let gapWidth = 10
    static let categoryViewWidth = arrowBtnWidth + tableViewWidth + 3 * gapWidth
    
    private var viewModel: CurrencyTransViewModel?
    private var disposeBag = DisposeBag()
    
    private var currencies: [String]? = [String]()
    private lazy var arrowBtn: UIButton = {
        let btn = UIButton()
        btn.setImage(UIImage(named: "arrow-down"), for: .normal)
        btn.setImage(UIImage(named: "arrow-up"), for: .selected)
        btn.imageView?.contentMode = .scaleToFill
        btn.addTarget(self, action: #selector(changeCurrentCurrency), for: .touchUpInside)
        return btn
    }()
    
    private lazy var currentCurrencyLabel: UILabel = {
        let label = UILabel()
        label.textColor = .red
        label.font = .systemFont(ofSize: 10)
        label.textAlignment = .center
        return label
    }()
    
    private lazy var tableView: UITableView = {
        let view = UITableView()
        view.delegate = self
        view.dataSource = self
        view.showsVerticalScrollIndicator = false
        view.isScrollEnabled = false
        view.isPagingEnabled = true
        view.alpha = 0.0
        view.separatorStyle = .none
        view.rowHeight = CurrencyCategoryTableCell.height
        view.register(CurrencyCategoryTableCell.self, forCellReuseIdentifier: CurrencyCategoryTableCell.CurrencyCategoryTableCellReuseIdentifier)
        return view
    }()
    
    init(frame: CGRect, viewModel: CurrencyTransViewModel) {
        super.init(frame: frame)
        self.viewModel = viewModel
        setupObserver()
        setupUI()
        layoutViews()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

// MARK: private method
extension CurrenciesCategoryView {
    private func setupObserver() {
        viewModel?.rx_currencies.subscribe(onNext: { [weak self] value in
            guard let self = self else { return }
            self.currencies = value
            self.tableView.reloadData()
        }).disposed(by: disposeBag)
    }
    
    private func setupUI() {
        addSubview(arrowBtn)
        addSubview(currentCurrencyLabel)
        currentCurrencyLabel.text = viewModel?.rx_currentCurrencyVar.value.uppercased()
        addSubview(tableView)
    }
    
    private func layoutViews() {
        arrowBtn.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.right.equalToSuperview().offset(-CurrenciesCategoryView.gapWidth)
            make.width.equalTo(CurrenciesCategoryView.arrowBtnWidth)
            make.height.equalTo(CurrenciesCategoryView.arrowBtnHeight)
        }
        currentCurrencyLabel.snp.makeConstraints { make in
            make.left.equalToSuperview().offset(CurrenciesCategoryView.gapWidth)
            make.centerY.equalToSuperview()
            make.width.equalTo(CurrenciesCategoryView.tableViewWidth)
            make.height.equalTo(CurrenciesCategoryView.tableViewHeight)
        }
        tableView.snp.makeConstraints { make in
            make.left.equalToSuperview().offset(CurrenciesCategoryView.gapWidth)
            make.width.equalTo(CurrenciesCategoryView.tableViewWidth)
            make.height.equalTo(CurrenciesCategoryView.tableViewHeight)
            make.top.equalTo(self.snp.bottom)
        }
    }
}

// MARK: UITableViewDelegate
extension CurrenciesCategoryView : UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let currencyTitle = currencies?[indexPath.row] {
            currentCurrencyLabel.text = currencyTitle
            viewModel?.rx_currentCurrencyVar.accept(currencyTitle)
            arrowBtn.sendActions(for: .touchUpInside)
        }
    }
}

// MARK: UITableViewDataSource
extension CurrenciesCategoryView : UITableViewDataSource {
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: CurrencyCategoryTableCell.CurrencyCategoryTableCellReuseIdentifier, for: indexPath) as? CurrencyCategoryTableCell else {return UITableViewCell()}
        if let currencyTitle = currencies?[indexPath.row] {
            cell.updateCell(title: currencyTitle)
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.currencies?.count ?? 0
    }
}

// MARK: action
extension CurrenciesCategoryView {
    @objc private func changeCurrentCurrency() {
        guard let count = viewModel?.rx_currencies.value.count, count > 1 else { return }
        arrowBtn.isSelected = !arrowBtn.isSelected
        UIView.animate(withDuration: 0.1) {
            self.tableView.alpha = self.arrowBtn.isSelected ? 1.0 : 0.0
            if self.arrowBtn.isSelected == true {
                self.tableView.snp.updateConstraints { make in
                    make.height.equalTo(CurrenciesCategoryView.tableViewHeight + 200)
                }
            } else {
                self.tableView.snp.updateConstraints { make in
                    make.height.equalTo(CurrenciesCategoryView.tableViewHeight)
                }
            }
            self.layoutIfNeeded()
        } completion: { isFinish in
            self.tableView.isScrollEnabled = true
        }
    }
    
    override func point(inside point: CGPoint, with event: UIEvent?) -> Bool {
        if (CGRectContainsPoint(tableView.frame, point)) {
            return true;
        }
        return super.point(inside: point, with: event)
    }
}
