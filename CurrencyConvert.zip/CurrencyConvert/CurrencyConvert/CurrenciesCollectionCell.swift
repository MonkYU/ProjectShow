//
//  CurrenciesCell.swift
//  CurrencyConvert
//
//  Created by allen on 2023/4/30.
//

import UIKit
import Foundation

/// collectionCell, display conversion result 
class CurrenciesCollectionCell: UICollectionViewCell {
    static public let CurrenciesCollectionCellReuseIdentifier = "CurrenciesCellReuseIdentifier"
    
    var transViewModel:CurrencyTransViewModel?
    
    private lazy var numberLabel: UILabel = {
        let label = UILabel()
        label.textColor = .red
        label.font = .systemFont(ofSize: 10)
        label.textAlignment = .center
        return label
    }()
    
    private lazy var currencyLabel: UILabel = {
        let label = UILabel()
        label.textColor = .red
        label.font = .systemFont(ofSize: 10)
        label.textAlignment = .center
        return label
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupUI()
        layoutViews()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

// MARK: private method
extension CurrenciesCollectionCell {
    private func setupUI() {
        layer.borderColor = UIColor.red.cgColor
        layer.borderWidth = 2
        contentView.addSubview(numberLabel)
        contentView.addSubview(currencyLabel)
    }
    
    private func layoutViews() {
        numberLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(12)
            make.left.right.equalToSuperview()
        }
        currencyLabel.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-10)
            make.centerX.equalToSuperview()
        }
    }
}

// MARK: public method
extension CurrenciesCollectionCell {
    func updateWithCurrency(currency: String) {
        currencyLabel.text = currency.uppercased()
        numberLabel.text = transViewModel?.getAmountForCurrency(currency: currency)
    }
}
