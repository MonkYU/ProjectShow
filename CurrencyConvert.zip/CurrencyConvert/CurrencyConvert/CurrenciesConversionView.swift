//
//  CurrenciesConversionView.swift
//  CurrencyConvert
//
//  Created by allen on 2023/4/30.
//

import Foundation
import UIKit
import SnapKit
import RxSwift

private let cellWidthHeight = 100.0
private let lineCount = 3.0

class CurrenciesConversionView: UIView {
    
    let spacing = (UIScreen.main.bounds.size.width - lineCount * cellWidthHeight) / (lineCount + 1)
    
    var transViewModel: CurrencyTransViewModel?
    private var currenciesFromMap: [String] = [String]()
    private var disposeBag = DisposeBag()
    
    private lazy var collectionView: UICollectionView = {
        let flowLayout = UICollectionViewFlowLayout()
        flowLayout.scrollDirection = .vertical;
        flowLayout.minimumLineSpacing = spacing
        flowLayout.itemSize = CGSize(width: cellWidthHeight, height: cellWidthHeight)
        flowLayout.minimumInteritemSpacing = spacing
        flowLayout.sectionInset = UIEdgeInsets(top: 0, left: spacing, bottom: 0, right: spacing)
        let view = UICollectionView(frame: .zero, collectionViewLayout: flowLayout)
        view.delegate = self
        view.dataSource = self
        view.register(CurrenciesCollectionCell.self, forCellWithReuseIdentifier: CurrenciesCollectionCell.CurrenciesCollectionCellReuseIdentifier)
        return view
    }()
    
    init(frame: CGRect, viewModel: CurrencyTransViewModel) {
        super.init(frame: frame)
        transViewModel = viewModel
        setupObserver()
        setupUI()
        layoutViews()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
 
// MARK: UICollectionViewDelegate
extension CurrenciesConversionView : UICollectionViewDelegate {
    
}

// MARK: UICollectionViewDataSource
extension CurrenciesConversionView : UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return currenciesFromMap.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CurrenciesCollectionCell.CurrenciesCollectionCellReuseIdentifier, for: indexPath) as? CurrenciesCollectionCell else { return UICollectionViewCell() }
        cell.transViewModel = transViewModel
        cell.updateWithCurrency(currency: currenciesFromMap[indexPath.item])
        return cell
    }
}

// MARK: private method
extension CurrenciesConversionView {
    private func setupUI() {
        addSubview(collectionView)
    }
    
    private func layoutViews() {
        collectionView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
    }
    
    private func setupObserver() {
        let _ = transViewModel?.rx_doubleMountVar.subscribe(onNext: { [weak self] amount in
            guard let self = self else { return }
            self.collectionView.reloadData()
        }).disposed(by: self.disposeBag)
        let _ = transViewModel?.rx_currentCurrencyVar.subscribe(onNext: { [weak self] currency in
            guard let self = self, let keys = self.transViewModel?.rx_latestmap.value?.keys.sorted(), keys.count > 0 else { return }
            self.filterCurrentCurrency(currentCurrency: currency, keys: keys)
            self.collectionView.reloadData()
        }).disposed(by: disposeBag)
        let _ = transViewModel?.rx_latestmap.subscribe(onNext: { [weak self] ret in
            guard let self = self, let keys = ret?.keys.sorted(), keys.count > 0 , let currency = transViewModel?.rx_currentCurrencyVar.value else { return }
            self.filterCurrentCurrency(currentCurrency: currency, keys: keys)
            collectionView.reloadData()
        }).disposed(by: self.disposeBag)
    }
    
    private func filterCurrentCurrency(currentCurrency: String, keys:[String]) {
        let convertKeys = keys.filter { value in
            return value.lowercased() != currentCurrency.lowercased()
        }
        currenciesFromMap = convertKeys
    }
}
